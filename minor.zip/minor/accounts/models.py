from django.db import models

# Create your models here.


class Reader(models.Model):
	name = models.CharField(max_length=200,null=True)
	email = models.CharField(max_length=200,null=True)
	date_created = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return self.name


class Gener(models.Model):
	name = models.CharField(max_length=200,null=True)

	def __str__(self):
		return self.name


def user_directory_path(name):  
    return 'book_{0}'.format(name)

class Book(models.Model):
	name = models.CharField(max_length=200,null=True)
	author = models.CharField(max_length=200,null=True)
	gener =  models.ManyToManyField(Gener)
	about = models.CharField(max_length=200,null=True)
	date_created = models.DateTimeField(auto_now_add=True)
	img = models.ImageField(upload_to = 'books', default='default.jpeg') 

	def __str__(self):
		return self.img.name

class Post(models.Model):
	title = models.CharField(max_length=200,null=True)
	author = models.ForeignKey(Reader,null=True,on_delete=models.SET_NULL)
	content = models.CharField(max_length=500,null=True)
	date_created = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return self.name